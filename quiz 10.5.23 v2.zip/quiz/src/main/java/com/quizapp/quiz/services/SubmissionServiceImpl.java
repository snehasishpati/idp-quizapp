package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.SubmissionRepository;
import com.quizapp.quiz.entities.Submissions;

@Service
public class SubmissionServiceImpl implements SubmissionService {

	@Autowired
	private SubmissionRepository submissionRepositoryObj;
	
	@Override
	public Submissions submitQuizResults(Submissions entry) {
		return submissionRepositoryObj.save(entry);
	}

	@Override
	public List<Submissions> getQuizSubmissions(Long quizId) {
		return submissionRepositoryObj.findAllByQuizId(quizId);
	}

}
