package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionService {

	public Submissions submitQuizResults(Submissions entry);
	public List<Submissions> getQuizSubmissions(Long quizId);
}
