package com.quizapp.quiz.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="quiz")
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long quizId;
	public String quizName;
	public boolean quizActive;
	public long totalQuestions;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="quiz_id")
	public List<Questions> questions;

	public Quiz(long quizId, String quizName, boolean quizActive, long totalQuestions, List<Questions> questions) {
		super();
		this.quizId = quizId;
		this.quizName = quizName;
		this.quizActive = quizActive;
		this.totalQuestions = totalQuestions;
		this.questions = questions;
	}

	public Quiz() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getQuizId() {
		return quizId;
	}

	public void setQuizId(long quizId) {
		this.quizId = quizId;
	}

	public String getQuizName() {
		return quizName;
	}

	public void setQuizName(String quizName) {
		this.quizName = quizName;
	}

	public boolean isQuizActive() {
		return quizActive;
	}

	public void setQuizActive(boolean quizActive) {
		this.quizActive = quizActive;
	}

	public long getTotalQuestions() {
		return totalQuestions;
	}

	public void setTotalQuestions(long totalQuestions) {
		this.totalQuestions = totalQuestions;
	}

	public List<Questions> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Questions> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Quiz [quizId=" + quizId + ", quizName=" + quizName + ", quizActive=" + quizActive + ", totalQuestions="
				+ totalQuestions + ", questions=" + questions + "]";
	}

	
}
