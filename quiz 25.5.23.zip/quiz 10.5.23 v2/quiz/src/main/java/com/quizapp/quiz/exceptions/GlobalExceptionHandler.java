package com.quizapp.quiz.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponse> handleResourceNotFoundException(ResourceNotFoundException exception){
		ApiResponse error = new ApiResponse("error", exception.getMessage());
		
		return new ResponseEntity<ApiResponse>(error, HttpStatus.NOT_FOUND);
	}
}
