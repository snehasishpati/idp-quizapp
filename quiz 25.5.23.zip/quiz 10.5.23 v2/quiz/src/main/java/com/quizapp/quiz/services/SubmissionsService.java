package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionsService {

	public Submissions submitQuizResults(Submissions submission);
	public List<Submissions> getSubmissions(Long quizId);
}
