package com.quizapp.quiz.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.SubmissionsRepository;
import com.quizapp.quiz.entities.Submissions;

@Service
public class SubmissionsServiceImpl implements SubmissionsService {

	@Autowired
	public SubmissionsRepository submissionsRepositoryObj;
	
	@Override
	public Submissions submitQuizResults(Submissions submission) {
		
		return submissionsRepositoryObj.save(submission);
	}

}
