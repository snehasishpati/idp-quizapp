package com.quiz.user.services;

import java.util.List;
import java.util.Optional;

import com.quiz.user.entities.User;

public interface UserService {

	public List<User> getUsers();
	public Optional<User> getUsers(int userId);
	public User registerUser(User user);
}
