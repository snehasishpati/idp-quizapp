package com.quiz.user.entities;

public class UserDTO {

	public int userId;
	
	public String username;
	
	public String email;
		
	public String role;

	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", username=" + username + ", email=" + email + ", role=" + role + "]";
	}

	public UserDTO(int userId, String username, String email, String role) {
		super();
		this.userId = userId;
		this.username = username;
		this.email = email;
		this.role = role;
	}

	public UserDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
