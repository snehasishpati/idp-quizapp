package com.quiz.user.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.user.entities.Login;
import com.quiz.user.entities.LoginResponse;
import com.quiz.user.entities.User;
import com.quiz.user.entities.UserDTO;
import com.quiz.user.services.UserService;

import jakarta.validation.Valid;

@RestController
public class userController {

	@Autowired
	private UserService UserServiceObj;

	// used to fetch details of all the users
	@GetMapping("/users")
	public List<UserDTO> getUsers() {
		return this.UserServiceObj.getUsers();
	}

	// used to fetch details of a single user.
	@GetMapping("/users/{userId}")
	public UserDTO getUserById(@PathVariable String userId) {
		return this.UserServiceObj.getUsers(Integer.parseInt(userId));
	}

	// used to register a new user
	@PostMapping("/users")
	public UserDTO registerUser(@Valid @RequestBody User user) {
		user.setRole("user");
		return this.UserServiceObj.registerUser(user);
	}

	// used to register a new user
	@PostMapping("/users/login")
	public ResponseEntity<LoginResponse> loginUser(@Valid @RequestBody Login user) {
		return this.UserServiceObj.loginUser(user);
	}
}
