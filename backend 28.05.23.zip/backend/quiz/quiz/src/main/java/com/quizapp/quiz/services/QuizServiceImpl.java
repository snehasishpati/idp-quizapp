package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.QuizRepository;
import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;
import com.quizapp.quiz.exceptions.ResourceNotFoundException;

@Service
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizRepository quizRepositoryObj;
	
	@Autowired 
	private QuestionsService questionsServiceObj;
	
	@Override
	public Quiz getQuiz(Long quizId) {
		Quiz quiz = quizRepositoryObj.findByQuizId(quizId).orElseThrow(()-> new ResourceNotFoundException("The quiz you are looking for doesn't exist."));
		if(!quiz.isQuizActive())
			throw new ResourceNotFoundException("The quiz you are looking for is no longer active");
		return quiz;
	}

	@Override
	public Quiz createQuiz(Quiz quiz) {
		return quizRepositoryObj.save(quiz);
	}
	
	@Override
	public Quiz UpdateQuiz(Quiz quiz) {
		checkIfQuizExists(quiz.getQuizId());
		return quizRepositoryObj.save(quiz);
	}

	@Override
	public List<Quiz> getAllQuizzes() {
		return quizRepositoryObj.findAll();
	}

	@Override
	public long submitQuiz(List<Questions> submission) {
		long score=0l;
		for(Questions entry : submission) {
			if(questionsServiceObj.isAnswerCorrect(entry)) {
				score++;
			}
		}
		return score;
	}

	@Override
	public void deleteQuiz(Long quizId) {
		checkIfQuizExists(quizId);
		quizRepositoryObj.deleteById(quizId);
	}

	@Override
	public boolean checkIfQuizExists(long quizId) {
		boolean isQuizExists = quizRepositoryObj.findByQuizId(quizId).isPresent();
		if(!isQuizExists)
			throw new ResourceNotFoundException("This quiz doesn't exist");
		return true;
	}
}
