package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.quizapp.quiz.dao.SubmissionsRepository;
import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.entities.User;

@Service
public class SubmissionsServiceImpl implements SubmissionsService {

	@Autowired
	public SubmissionsRepository submissionsRepositoryObj;
	
	@Autowired
	public RestTemplate restTemplate;
	
	@Autowired
	private QuizService quizObj;
		
	@Override
	public Submissions submitQuizResults(Submissions submission) {
		return submissionsRepositoryObj.save(submission);
	}

	@Override
	public List<Submissions> getSubmissions(Long quizId) {
		quizObj.checkIfQuizExists(quizId);
		
		List<Submissions> submissions = submissionsRepositoryObj.getAllByQuizId(quizId);
		
		for(Submissions submission : submissions) {
			User user = restTemplate.getForObject("http://USER-SERVICE/users/"+submission.getUserId(), User.class);
			submission.setUser(user);
		}
		return submissions;
	}

	@Override
	public Submissions getSubmissionsByQuizAndUserId(long quizId, long UserId) {
		return submissionsRepositoryObj.getSubmissionsByQuizAndUserId(quizId, UserId);
	}

}
