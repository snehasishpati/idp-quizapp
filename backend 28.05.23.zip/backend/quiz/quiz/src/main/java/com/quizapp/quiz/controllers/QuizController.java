package com.quizapp.quiz.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;
import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.exceptions.UnauthorizedAccessException;
import com.quizapp.quiz.services.QuestionsService;
import com.quizapp.quiz.services.QuizService;
import com.quizapp.quiz.services.SubmissionsService;

import jakarta.validation.Valid;

@RestController
public class QuizController {

	@Autowired
	private QuizService quizObj;
	
	@Autowired
	private QuestionsService questionsServiceObj;
	
	@Autowired
	private SubmissionsService submissionsServiceObj;

	
	//Returns data of all the quizzes in the database
	@GetMapping("/quiz/all")
	public List<Quiz> getAllQuizzes() {
		return this.quizObj.getAllQuizzes();
	}
	
	//Returns data of a particular quiz by taking its quiz id
	@GetMapping("/quiz/{quizId}/{accessMode}/user/{userId}")
	public Quiz getQuiz(@PathVariable String quizId, @PathVariable String accessMode, @PathVariable String userId) throws JsonProcessingException {
		Quiz response = this.quizObj.getQuiz(Long.parseLong(quizId));

		if(!accessMode.equals("edit")) {
			Submissions submission = this.submissionsServiceObj.getSubmissionsByQuizAndUserId(Long.parseLong(quizId), Long.parseLong(userId));
			if(submission != null)
				throw new UnauthorizedAccessException("You have already attempted the quiz");
			response.questions = questionsServiceObj.filterQuestionsForUser(response.questions);
		}
		return response;
	}
	
	//Adds a new quiz to the database and returns its details
	@PostMapping("/quiz")
	public Quiz createQuiz(@Valid @RequestBody Quiz quiz){
		return this.quizObj.createQuiz(quiz);
	}
	
	@PostMapping("/quiz/submit/{quiz_id}/{user_id}")
	public Submissions submitQuiz(@PathVariable String quiz_id, @PathVariable String user_id, @Valid @RequestBody List<Questions> submission) {
		quizObj.checkIfQuizExists(Long.parseLong(user_id));

		long score = this.quizObj.submitQuiz(submission);
		Quiz quiz = new Quiz();
		quiz.setQuizId(Long.parseLong(quiz_id));
		Submissions quizSubmission = new Submissions(score, Long.parseLong(user_id), quiz);		
		return submissionsServiceObj.submitQuizResults(quizSubmission);
	}
	
	@PutMapping("/quiz")
	public Quiz updateQuiz(@Valid @RequestBody Quiz quiz){
		return this.quizObj.UpdateQuiz(quiz);
	}
	
	@DeleteMapping("/quiz/{quizId}")
	public int deleteQuiz(@PathVariable String quizId){
		quizObj.deleteQuiz(Long.parseLong(quizId));
		return HttpStatus.SC_OK;
	}
}
