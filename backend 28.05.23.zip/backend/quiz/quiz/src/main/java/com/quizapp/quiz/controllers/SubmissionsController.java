package com.quizapp.quiz.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.services.SubmissionsService;

import jakarta.validation.Valid;

@RestController
public class SubmissionsController {
	
	@Autowired
	public SubmissionsService submissionsServiceObj;
	
	@PostMapping("/quiz/submissions")
	public Submissions saveSubmission(@Valid @RequestBody Submissions submission) {
		return this.submissionsServiceObj.submitQuizResults(submission);
	}
	
	@GetMapping("/quiz/submissions/{quizId}")
	public List<Submissions> getSubmissions(@PathVariable String quizId){
		return this.submissionsServiceObj.getSubmissions(Long.parseLong(quizId));
	}

}
