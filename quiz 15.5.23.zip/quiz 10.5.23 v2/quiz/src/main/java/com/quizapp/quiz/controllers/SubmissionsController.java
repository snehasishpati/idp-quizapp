package com.quizapp.quiz.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.services.SubmissionsService;

@RestController
public class SubmissionsController {
	
	@Autowired
	public SubmissionsService submissionsServiceObj;
	
	@PostMapping("/submissions")
	public Submissions saveSubmission(@RequestBody Submissions submission) {
		return this.submissionsServiceObj.submitQuizResults(submission);
	}
}
