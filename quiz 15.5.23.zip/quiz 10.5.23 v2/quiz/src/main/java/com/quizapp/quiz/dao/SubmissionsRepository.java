package com.quizapp.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionsRepository extends JpaRepository<Submissions, Long> {

}
