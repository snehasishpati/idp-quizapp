package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.QuizRepository;
import com.quizapp.quiz.entities.Quiz;

@Service
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizRepository quizRepositoryObj;
	
	@Override
	public Quiz getQuiz(Long quizId) {
		return quizRepositoryObj.findByQuizId(quizId);
	}

	@Override
	public Quiz createQuiz(Quiz quiz) {
		return quizRepositoryObj.save(quiz);
	}

	@Override
	public List<Quiz> getAllQuizzes() {
		return quizRepositoryObj.findAll();
	}

}
