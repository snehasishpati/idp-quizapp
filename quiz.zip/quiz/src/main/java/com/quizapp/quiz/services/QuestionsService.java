package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Questions;

public interface QuestionsService {

	public List<Questions> getQuestions(Long quizId); 
	public List<Questions> createQuestions(List<Questions> questions); 

}
