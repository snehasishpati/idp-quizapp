package com.quizapp.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quizapp.quiz.entities.Quiz;

public interface QuizRepository extends JpaRepository<Quiz, Long> {

	public Quiz findByQuizId(Long quizId);
}
