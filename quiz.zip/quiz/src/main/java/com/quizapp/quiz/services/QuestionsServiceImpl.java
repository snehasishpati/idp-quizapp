package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.QuestionsRepository;
import com.quizapp.quiz.entities.Questions;

@Service
public class QuestionsServiceImpl implements QuestionsService {

	@Autowired
	private QuestionsRepository QuestionsRepositoryObj;
	
	@Override
	public List<Questions> getQuestions(Long quizId) {
		// TODO Auto-generated method stub
		return QuestionsRepositoryObj.findAllByQuizId(quizId);
	}

	@Override
	public List<Questions> createQuestions(List<Questions> questions) {
		return QuestionsRepositoryObj.saveAll(questions);
	}

}
