package com.quizapp.quiz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quizapp.quiz.entities.Questions;

public interface QuestionsRepository extends JpaRepository<Questions, Long> {

	public List<Questions> findAllByQuizId(Long quizId);

}
