package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Quiz;

public interface QuizService {

	public Quiz getQuiz(Long quizId);
	
	public List<Quiz> getAllQuizzes();
	
	public Quiz createQuiz(Quiz quiz);
}
