package com.quizapp.quiz.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionRepository extends JpaRepository<Submissions, Long> {

	public List<Submissions> findAllByQuizId(Long quizId);

}
