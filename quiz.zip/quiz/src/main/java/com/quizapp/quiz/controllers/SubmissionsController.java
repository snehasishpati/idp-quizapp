package com.quizapp.quiz.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.services.SubmissionService;

@RestController
public class SubmissionsController {
	
	@Autowired
	private SubmissionService submissionServiceObj;

	@PostMapping("/submit")
	public Submissions submitQuiz(@RequestBody Submissions submission){
		return this.submissionServiceObj.submitQuiz(submission);
	}
	
	@GetMapping("/submissions/{quizId}")
	public List<Submissions> getSubmissionByQuizId(@PathVariable String quizId) {
		return this.submissionServiceObj.getQuizSubmissions(Long.parseLong(quizId));
	}
}
