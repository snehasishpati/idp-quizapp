package com.quizapp.quiz.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="quiz")
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long quizId;
	public String quizName;
	public boolean quizActive;
	public long totalQuestions;
	
	public Quiz(long quizId, String quizName, boolean quizActive, long totalQuestions) {
		super();
		this.quizId = quizId;
		this.quizName = quizName;
		this.quizActive = quizActive;
		this.totalQuestions = totalQuestions;
	}

	public Quiz() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getQuizId() {
		return quizId;
	}

	public void setQuizId(long quizId) {
		this.quizId = quizId;
	}

	public String getQuizName() {
		return quizName;
	}

	public void setQuizName(String quizName) {
		this.quizName = quizName;
	}

	public boolean quizActive() {
		return quizActive;
	}

	public void setQuizOpen(boolean quizActive) {
		this.quizActive = quizActive;
	}

	public long getTotalQuestions() {
		return totalQuestions;
	}

	public void setTotalQuestions(long totalQuestions) {
		this.totalQuestions = totalQuestions;
	}

	@Override
	public String toString() {
		return "Quiz [quizId=" + quizId + ", quizName=" + quizName + ", quizActive=" + quizActive + ", totalQuestions="
				+ totalQuestions + "]";
	}

}
