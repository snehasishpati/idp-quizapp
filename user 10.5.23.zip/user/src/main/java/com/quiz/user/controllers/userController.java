package com.quiz.user.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.user.entities.User;
import com.quiz.user.services.UserService;

@RestController
public class userController {
	
	@Autowired
	private UserService UserServiceObj;
	
	//used to fetch details of all the users
	@GetMapping("/users")
	public List<User> getUsers() {
		return this.UserServiceObj.getUsers();
	}
	
	//used to fetch details of a single user. 
	@GetMapping("/users/{userId}")
	public String getUserById(@PathVariable String userId) {
		return "user";
	}
	
	//used to register a new user
	@PostMapping("/users")
	public User registerUser(@RequestBody User user) {
		return this.UserServiceObj.registerUser(user);
	}
}
