package com.quiz.user.services;

import java.util.List;

import com.quiz.user.entities.User;

public interface UserService {

	public List<User> getUsers();
	public User registerUser(User user);
}
