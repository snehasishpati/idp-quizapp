package com.quiz.user.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quiz.user.dao.UserDao;
import com.quiz.user.entities.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao UserDaoObj; 

	@Override
	public List<User> getUsers() {
		return UserDaoObj.findAll();
	}

	@Override
	public User registerUser(User user) {
		UserDaoObj.save(user);
		return user;
	}

}
