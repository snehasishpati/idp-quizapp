package com.quizapp.quiz.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="submissions")
public class Submissions {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long submissionId;
	public Long quizId;
	public Long userId;
	public Long totalCorrect;
	
	public Submissions(Long submissionId, Long quizId, Long userId, Long totalCorrect) {
		super();
		this.submissionId = submissionId;
		this.quizId = quizId;
		this.userId = userId;
		this.totalCorrect = totalCorrect;
	}

	public Submissions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getSubmissionId() {
		return submissionId;
	}

	public void setSubmissionId(Long submissionId) {
		this.submissionId = submissionId;
	}

	public Long getQuizId() {
		return quizId;
	}

	public void setQuizId(Long quizId) {
		this.quizId = quizId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getTotalCorrect() {
		return totalCorrect;
	}

	public void setTotalCorrect(Long totalCorrect) {
		this.totalCorrect = totalCorrect;
	}

	@Override
	public String toString() {
		return "Submissions [submissionId=" + submissionId + ", quizId=" + quizId + ", userId=" + userId
				+ ", totalCorrect=" + totalCorrect + "]";
	}
	
}
