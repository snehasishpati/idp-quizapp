package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionService {

	public Submissions submitQuiz(Submissions entry);
	public List<Submissions> getQuizSubmissions(Long quizId);
}
