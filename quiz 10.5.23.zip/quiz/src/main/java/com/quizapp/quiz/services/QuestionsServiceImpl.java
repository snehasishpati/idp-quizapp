package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.QuestionsRepository;
import com.quizapp.quiz.entities.Questions;

@Service
public class QuestionsServiceImpl implements QuestionsService {

	@Autowired
	private QuestionsRepository QuestionsRepositoryObj;
	
	@Override
	public List<Questions> getQuestionsWithAnswers(Long quizId) {
		return QuestionsRepositoryObj.getAllWithAnswers(quizId);
	}

	@Override
	public List<Questions> createQuestions(List<Questions> questions) {
		return QuestionsRepositoryObj.saveAll(questions);
	}

	@Override
	public List<Questions> getQuestionsWithoutAnswers(Long quizId) {
		return QuestionsRepositoryObj.getAllWithoutAnswers(quizId);
	}
	
	@Override
	public boolean isAnswerCorrect(Questions entry) {
		if(QuestionsRepositoryObj.findByQuestionId(entry.questionId).answer.equalsIgnoreCase(entry.submittedAnswer))
			return true;
		return false;
	}

	@Override
	public List<Questions> filterQuestionsForUser(List<Questions> questions) {
//		List<Ques>
		for(Questions entry: questions) {
			entry.answer = null;
		}
		return questions;
	}

}
