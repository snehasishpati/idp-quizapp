package com.quizapp.quiz.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;
import com.quizapp.quiz.services.QuestionsService;
import com.quizapp.quiz.services.QuizService;

@RestController
public class QuizController {

	@Autowired
	private QuizService quizObj;
	
	@Autowired
	private QuestionsService questionsServiceObj;
	
	//Returns data of all the quizzes in the database
	@GetMapping("/quizzes")
	public List<Quiz> getAllQuizzes() {
		return this.quizObj.getAllQuizzes();
	}
	
	//Returns data of a particular quiz by taking its quiz id
	@GetMapping("/quiz/{quizId}/{accessMode}")
	public Quiz getQuiz(@PathVariable String quizId, @PathVariable String accessMode) {
		Quiz response = this.quizObj.getQuiz(Long.parseLong(quizId));
		
		if(accessMode.equals("attempt")) {
			response.questions = questionsServiceObj.filterQuestionsForUser(response.questions);
		}
		return response;
	}
	
	//Adds a new quiz to the database and returns its details
	@PostMapping("/quiz")
	public Quiz createQuiz(@RequestBody Quiz quiz){
		return this.quizObj.createUpdateQuiz(quiz);
	}
	
	@PostMapping("/submit")
	public long submitQuiz(@RequestBody List<Questions> submission) {
		return quizObj.submitQuiz(submission);
	}
	
	@PutMapping("/quiz")
	public Quiz updateQuiz(@RequestBody Quiz quiz){
		return this.quizObj.createUpdateQuiz(quiz);
	}
}
