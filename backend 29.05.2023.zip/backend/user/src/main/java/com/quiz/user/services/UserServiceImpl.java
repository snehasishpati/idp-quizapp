package com.quiz.user.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.quiz.user.dao.UserDao;
import com.quiz.user.entities.Login;
import com.quiz.user.entities.LoginResponse;
import com.quiz.user.entities.User;
import com.quiz.user.entities.UserDTO;
import com.quiz.user.exceptions.ResourceAlreadyExistsException;
import com.quiz.user.exceptions.ResourceNotFoundException;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao UserDaoObj; 
	
	ModelMapper modelMapper = new ModelMapper();

	@Override
	public List<UserDTO> getUsers() {
		List<User> users = UserDaoObj.findAll();
		List<UserDTO> usersDto = new ArrayList<>();
		for (User user : users) {
			usersDto.add(modelMapper.map(user, UserDTO.class));
		}
		return usersDto;
	}

	@Override
	public UserDTO registerUser(User user) {
		Optional<User> existingUser  = UserDaoObj.findByEmail(user.getEmail());
		if(existingUser.isPresent()) {
			throw new ResourceAlreadyExistsException("User with this email id already exists");
		}
		UserDaoObj.save(user);
		return modelMapper.map(user, UserDTO.class);
	}

	@Override
	public UserDTO getUsers(int userId) {
		User user = UserDaoObj.findById(userId).orElseThrow(()-> new ResourceNotFoundException("The user doesn't exist"));
		UserDTO userDto = modelMapper.map(user, UserDTO.class);
		return userDto;
	}

	@Override
	public ResponseEntity<LoginResponse> loginUser(Login user) {
		User userDetails = UserDaoObj.findByEmail(user.getEmail()).orElseThrow(()-> new ResourceNotFoundException("User doesn't exist, please enter a registered email"));
		LoginResponse resp = new LoginResponse();
		if(userDetails != null) {
			if(userDetails.getPassword().equals(user.getPassword())) {
				UserDTO userDto = modelMapper.map(userDetails, UserDTO.class);
				
				resp.setStatus("success");
				resp.setMessage("Login successful");
				resp.setUser(userDto);
				
				return new ResponseEntity<LoginResponse>(resp, HttpStatus.OK);
			}
		}
		return new ResponseEntity<LoginResponse>(resp, HttpStatus.UNAUTHORIZED);
	}

}
