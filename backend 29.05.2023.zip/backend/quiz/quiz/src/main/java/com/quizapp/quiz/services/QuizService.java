package com.quizapp.quiz.services;

import java.util.List;

import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;

public interface QuizService {

	Quiz getQuiz(Long quizId);
	
	List<Quiz> getAllQuizzes();
	
	long submitQuiz(List<Questions> submission);

	void deleteQuiz(Long quizId);

	Quiz createQuiz(Quiz quiz);

	Quiz UpdateQuiz(Quiz quiz);
	
	boolean checkIfQuizExists(long quizId);
}
