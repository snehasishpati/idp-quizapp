package com.quizapp.quiz.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.services.SubmissionsService;

@RestController
public class SubmissionsController {
	
	@Autowired
	public SubmissionsService submissionsServiceObj;
	
	@PostMapping("/submissions")
	public Submissions saveSubmission(@RequestBody Submissions submission) {
		return this.submissionsServiceObj.submitQuizResults(submission);
	}
	
	@GetMapping("/submissions/{quizId}")
	public List<Submissions> getSubmissions(@PathVariable String quizId){
		return this.submissionsServiceObj.getSubmissions(Long.parseLong(quizId));
	}

}
