package com.quizapp.quiz.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;
import com.quizapp.quiz.entities.Submissions;
import com.quizapp.quiz.services.QuestionsService;
import com.quizapp.quiz.services.QuizService;
import com.quizapp.quiz.services.SubmissionsService;

@RestController
public class QuizController {

	@Autowired
	private QuizService quizObj;
	
	@Autowired
	private QuestionsService questionsServiceObj;
	
	@Autowired
	private SubmissionsService submissionsServiceObj;

	
	//Returns data of all the quizzes in the database
	@GetMapping("/quizzes")
	public List<Quiz> getAllQuizzes() {
		return this.quizObj.getAllQuizzes();
	}
	
	//Returns data of a particular quiz by taking its quiz id
	@GetMapping("/quiz/{quizId}/{accessMode}")
	public Quiz getQuiz(@PathVariable String quizId, @PathVariable String accessMode) throws JsonProcessingException {
		Quiz response = this.quizObj.getQuiz(Long.parseLong(quizId));

		if(!accessMode.equals("edit")) {
			response.questions = questionsServiceObj.filterQuestionsForUser(response.questions);
		}
		return response;
	}
	
	//Adds a new quiz to the database and returns its details
	@PostMapping("/quiz")
	public Quiz createQuiz(@RequestBody Quiz quiz){
		return this.quizObj.createUpdateQuiz(quiz);
	}
	
	@PostMapping("/submit/{quiz_id}/{user_id}")
	public Submissions submitQuiz(@PathVariable String quiz_id, @PathVariable String user_id, @RequestBody List<Questions> submission) {
		
		long score = this.quizObj.submitQuiz(submission);
		Quiz quiz = new Quiz();
		quiz.setQuizId(Long.parseLong(quiz_id));
		Submissions quizSubmission = new Submissions(score, Long.parseLong(user_id), quiz);		
		return submissionsServiceObj.submitQuizResults(quizSubmission);
	}
	
	@PutMapping("/quiz")
	public Quiz updateQuiz(@RequestBody Quiz quiz){
		return this.quizObj.createUpdateQuiz(quiz);
	}
	
	@DeleteMapping("/quiz/{quizId}")
	public int deleteQuiz(@PathVariable String quizId){
		quizObj.deleteQuiz(Long.parseLong(quizId));
		return HttpStatus.SC_OK;
	}
}
