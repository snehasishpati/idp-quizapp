package com.quizapp.quiz.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quiz.dao.QuizRepository;
import com.quizapp.quiz.entities.Questions;
import com.quizapp.quiz.entities.Quiz;
import com.quizapp.quiz.exceptions.ResourceNotFoundException;

@Service
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizRepository quizRepositoryObj;
	
	@Autowired 
	private QuestionsService questionsServiceObj;
	
	@Override
	public Quiz getQuiz(Long quizId) {
		return quizRepositoryObj.findByQuizId(quizId).orElseThrow(()-> new ResourceNotFoundException("The quiz you are looking for doesn't exist."));
	}

	@Override
	public Quiz createUpdateQuiz(Quiz quiz) {
		return quizRepositoryObj.save(quiz);
	}

	@Override
	public List<Quiz> getAllQuizzes() {
		return quizRepositoryObj.findAll();
	}

	@Override
	public long submitQuiz(List<Questions> submission) {
		long score=0l;
		for(Questions entry : submission) {
			if(questionsServiceObj.isAnswerCorrect(entry)) {
				score++;
			}
		}
		return score;
	}

	@Override
	public void deleteQuiz(Long quizId) {
		quizRepositoryObj.deleteById(quizId);
	}
}
