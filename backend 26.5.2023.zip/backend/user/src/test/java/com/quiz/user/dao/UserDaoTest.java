package com.quiz.user.dao;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.quiz.user.entities.User;

@DataJpaTest
public class UserDaoTest {

	@Autowired
	private UserDao userDao;
	User user;
	
	@BeforeEach
	void setUp() {
		user = new User(1, "Snehasish", "xyz@gmail.com", "babun", "admin");
		userDao.save(user);
	}
	
	@AfterEach
	void tearDown() {
		userDao.deleteAll();
	}
	
	@Test
	void testFindById() {
		List<User> users = userDao.findAll();
		assertThat(users.get(0).getEmail()).isEqualTo(user.getEmail());
	}
}
