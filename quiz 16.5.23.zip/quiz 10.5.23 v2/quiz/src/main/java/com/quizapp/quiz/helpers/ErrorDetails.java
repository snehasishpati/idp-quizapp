package com.quizapp.quiz.helpers;

public class ErrorDetails {

	public String errorType;
	public String message;
	public String details;
	
	public ErrorDetails(String errorType, String message, String details) {
		super();
		this.errorType = errorType;
		this.message = message;
		this.details = details;
	}

	public ErrorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
}
