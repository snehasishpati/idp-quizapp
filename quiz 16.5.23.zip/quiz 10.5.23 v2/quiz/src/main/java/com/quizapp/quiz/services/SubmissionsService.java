package com.quizapp.quiz.services;

import com.quizapp.quiz.entities.Submissions;

public interface SubmissionsService {

	public Submissions submitQuizResults(Submissions submission);
}
